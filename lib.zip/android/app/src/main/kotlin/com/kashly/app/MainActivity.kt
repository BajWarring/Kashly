package com.kashly.app

// ✅ V2 embedding — replaces the deleted io.flutter.app.FlutterActivity (v1)
import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
